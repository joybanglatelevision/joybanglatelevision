<?php global $themesdealer; ?>
<!------------ Main Body Section Close -------------->

<section class="footer_logo_section">
<?php if($themesdealer['full-body-website'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['full-body-website'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>

	<div class="row">
		<div class="col-md-3 col-sm-4">
			<div class="footer_logo">
				<a href="<?php bloginfo('url'); ?>"><img src="<?php echo $themesdealer['ftlogo_upload']['url']?>" alt="Logo" width="100%"></a>
			</div>
		</div>
		<div class="col-md-9 col-sm-8"></div>
	</div>

</div>
</section>


<section class="footer_menu_section">
<?php if($themesdealer['full-body-website'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['full-body-website'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>

		<div class="row">
		
			<div class="col-xs-4 col-sm-2 col-md-2">
				<div class="footer-menu">
					<?php
						wp_nav_menu( array('theme_location' => 'ft-menuone',
					)); ?>
				</div>
			</div>
			<div class="col-xs-4 col-sm-2 col-md-2">
				<div class="footer-menu">
					<?php
						wp_nav_menu( array('theme_location' => 'ft-menutwo',
					)); ?>
				</div>
			</div>
			<div class="col-xs-4 col-sm-2 col-md-2">
				<div class="footer-menu">
					<?php
						wp_nav_menu( array('theme_location' => 'ft-menuthree',
					)); ?>
				</div>
			</div>
			<div class="col-xs-4 col-sm-2 col-md-2">
				<div class="footer-menu">
					<?php
						wp_nav_menu( array('theme_location' => 'ft-menufour',
					)); ?>
				</div>
			</div>
			<div class="col-xs-4 col-sm-2 col-md-2">
				<div class="footer-menu">
					<?php
						wp_nav_menu( array('theme_location' => 'ft-menufive',
					)); ?>
				</div>
			</div>
			<div class="col-xs-4 col-sm-2 col-md-2">
				<div class="footer-menu">
					<?php
						wp_nav_menu( array('theme_location' => 'ft-menusix',
					)); ?>
				</div>
			</div>

		</div>

</div>
</section>


<section class="footer_content_section">
<?php if($themesdealer['full-body-website'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['full-body-website'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>

	<div class="row">
		<div class="col-md-8 col-sm-8">
			<div class="ftr_text">
				<?php echo $themesdealer['address']?>
			</div>
		</div>
		<div class="col-md-4 col-sm-4">
			<?php if($themesdealer['facebook'] == 1 ): ?>		
			<div class="fb-root">
				<script>(function(d, s, id) {
				  var js, fjs = d.getElementsByTagName(s)[0];
				  if (d.getElementById(id)) return;
				  js = d.createElement(s); js.id = id;
				  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
				  fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));</script>
				<div class="fb-page" data-href="<?php echo $themesdealer['facebook-link']['face-url']; ?>" data-tabs="timeline" data-width="<?php echo $themesdealer['facebook-width']?>" data-height="<?php echo $themesdealer['facebook-height']?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
			 </div>
		
			<?php endif; ?>   
			<?php if($themesdealer['facebook'] == 2 ): ?>
			<?php endif; ?>
			
			<section class="widget_section">
				<?php dynamic_sidebar('footer_widget')?>
			</section>
	
		</div>
	</div>

</div>
</section>








<?php 
get_template_part('/framework/codestyles/funtion');
wp_footer();
?>

</body>
</html> 