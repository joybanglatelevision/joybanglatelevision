<?php get_header();
global $themesdealer; ?>

<?php if($themesdealer['tvsec-show'] == 1 ): ?>				
	
<?php get_template_part('live');
get_template_part('scrool');
get_template_part('datesocial');
get_template_part('menu');?>

<?php endif; ?>  
<?php if($themesdealer['tvsec-show'] == 2 ): ?>	

<?php 
get_template_part('singlehead');
?>
 				
<?php endif; ?>

