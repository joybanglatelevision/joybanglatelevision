<?php /* Template Name: Video Catagory Page */ ?>
<?php get_header();
global $themesdealer; ?>
<?php 
get_template_part('singlehead');
?>




<!------------ Header Menu Section Close -------------->

<section class="main_body_section">
    
	<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container website_body">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>	
    
    
        
        <div class="row">
            <div class="col-md-9 col-sm-8">
               
               <section class="page_section">

                   
                    <?php if($themesdealer['videocat-one-button'] == 1 ): ?>
					
					<div class="row">
						
						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-one'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-one'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-two'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-two'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

					</div>


					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_01')?>
					</section>

                    <?php endif; ?>   
					<?php if($themesdealer['videocat-one-button'] == 2 ): ?>
					<?php endif; ?>
					
                    <?php if($themesdealer['videocat-three-button'] == 1 ): ?>
					
					<div class="video_section_two">
					<div class="row">
						
						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-three'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-three'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-four'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-four'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

					</div>
					</div>


					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_02')?>
					</section>

                    <?php endif; ?>   
					<?php if($themesdealer['videocat-three-button'] == 2 ): ?>
					<?php endif; ?>

                   
                    <?php if($themesdealer['videocat-five-button'] == 1 ): ?>
					
					<div class="video_section_two">
					<div class="row">
						
						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-five'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-five'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-six'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-six'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

					</div>
					</div>


					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_03')?>
					</section>

                    <?php endif; ?>   
					<?php if($themesdealer['videocat-five-button'] == 2 ): ?>
					<?php endif; ?>

                   
                    <?php if($themesdealer['videocat-seven-button'] == 1 ): ?>
					
					<div class="video_section_two">
					<div class="row">
						
						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-seven'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-seven'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-eight'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-eight'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

					</div>
					</div>


					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_04')?>
					</section>

                    <?php endif; ?>   
					<?php if($themesdealer['videocat-seven-button'] == 2 ): ?>
					<?php endif; ?>

                   
                    <?php if($themesdealer['videocat-nine-button'] == 1 ): ?>
					
					<div class="video_section_two">
					<div class="row">
						
						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-nine'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-nine'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

						<div class="col-md-6 col-sm-6">
							
							<?php
								$cat = $themesdealer['videocat-ten'];
								$category_name = get_the_category_by_id($cat);
								$category_name_link = get_category_link($cat); 
								?>
								
							<div class="video_cat_title">
								<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
							</div>

							<div class="row">
							   <div class="col-md-12">
								   <div class="tv_videoslide_padding">
										<div class="tv_videoslide_catagory">
											<div class="videoslide_catagory owl-carousel">
												
												<?php
												$category_name = get_the_category_by_id($cat);
												$how_cat= $themesdealer['how_post_videocat-ten'];
												$total_how_cat=$how_cat-0;
												$themes_dealer = new WP_Query(array(
													'post_type' => 'post',
													'posts_per_page' => $total_how_cat,
													'offset' => 0,
													'cat' => $cat,

												));
												while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
												
												<div class="box_shadow_two">
													<div class="leadnews_image">
														<div class="news_video_sec">
															<a href="<?php the_permalink()?>">
																<?php if(has_post_thumbnail()){ 
																	the_post_thumbnail();}
																	else{?>
																<div class="news_video">
																	<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
																		<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
																		echo wp_oembed_get( $url );?>
																	</div>
																</div>
																<i class="fa fa-play" aria-hidden="true"></i>
																<?php } ?>
															</a>
														</div>
														
														<div class="content_padding">
															<div class="lead_height_1">
																<div class="heading_1">
																	<a href="<?php the_permalink()?>"><?php the_title() ?></a>
																 </div>
															 </div>
														 </div>
													</div>
												</div>

												<?php endwhile?>

											</div>
										</div>
													
									</div>
							   </div> 
							</div>
						</div>

					</div>
					</div>

					<section class="widget_section">
						<?php dynamic_sidebar('widget_area_05')?>
					</section>
				   
				   
                    <?php endif; ?>   
					<?php if($themesdealer['videocat-nine-button'] == 2 ): ?>
					<?php endif; ?>

                   

               </section> 

            </div>
            <div class="col-md-3 col-sm-4">
                
                <div class="tab-header">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-justified" role="tablist">
                        <li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo $themesdealer['last'] ?></a></li>
						<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"><?php echo $themesdealer['popular'] ?></a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content ">
                        <div role="tabpanel" class="tab-pane in active" id="tab21">

                            <div class="news-titletab">
                                
								<?php							 
									$lastnews = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $themesdealer['lastpost'],
									'offset' =>0,
									));
									while($lastnews->have_posts()) : $lastnews->the_post();?>
									
								<div class="heading_2 tav_border">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                 </div>
                                 
								 <?php endwhile ?>
								 
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                            <div class="news-titletab">
                                
								<?php	
								query_posts('meta_key=post_views_count&orderby=meta_value_num&order=DESC');
								if (have_posts()) : while (have_posts()) : the_post();
								?>
								
								<div class="heading_2 tav_border">
                                    <i class="fa fa-angle-double-right" aria-hidden="true"></i> <a href="<?php the_permalink()?>"><?php the_title() ?></a>
                                 </div>

								<?php
								endwhile; endif;
								wp_reset_query();
								?>
										
                            </div>                                          
                        </div>
                    </div>
                </div>

                <!------------ Tab Close -------------->

                <section class="single_widget_section">
					<?php dynamic_sidebar('page_sidebar')?>
				</section>


                









            </div>
        </div>

    </div>
</section>

<?php get_footer(); 
			?>