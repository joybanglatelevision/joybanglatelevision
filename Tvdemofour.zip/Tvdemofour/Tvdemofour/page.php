<?php get_header();
global $themesdealer; ?>
<?php 
get_template_part('singlehead');
?>

<!------------ Main Body Section  Start-------------->

<section class="main_body_section">
    
	<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container website_body">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>	
        
        <div class="row">
            <div class="col-md-8 col-sm-8">
               
               <section class="page_section">             
						
				   <?php if(have_posts()) : ?>
						<?php while(have_posts()) : the_post(); ?>
                   
                   <div class="archive_title">
                        <a href="<?php bloginfo('url');?>"> <i class="fa fa-home"></i> </a> /  <?php the_title();?> 
                    </div>

                    <div class="single_title">
                        <?php the_title();?>
                    </div>


                    

                        <div class="single_img">
                            <?php the_post_thumbnail();?>
                        </div>

                        <div class="single_dtails">
						
                            <?php the_content();?>
							
                        </div>

                         <?php endwhile;?>
						<?php endif;?> 

               </section> 

            </div>
            <div class="col-md-4 col-sm-4">
                
                <div class="tab-header">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs nav-justified" role="tablist">
                        <li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo $themesdealer['last'] ?></a></li>
						<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"><?php echo $themesdealer['popular'] ?></a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content ">
                        <div role="tabpanel" class="tab-pane in active" id="tab21">

                            <div class="news-titletab">
                                
								<?php							 
									$lastnews = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $themesdealer['lastpost'],
									'offset' =>0,
									));
									while($lastnews->have_posts()) : $lastnews->the_post();?>
								
								<div class="single_tab_sec">
									<a href="<?php the_permalink()?>">
										<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
										<div class="single_tabimage_video">
											<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
												<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
												echo wp_oembed_get( $url );?>
											</div>
										</div>
										<i class="fa fa-play" aria-hidden="true"></i>
										<?php } ?>
									</a>
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>

                            <div class="single_tab_border"></div>
							
							<?php endwhile ?>
							
                            


                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                            <div class="news-titletab">
                                <?php	
								query_posts('meta_key=post_views_count&orderby=meta_value_num&order=DESC');
								if (have_posts()) : while (have_posts()) : the_post();
								?>
								
								<div class="single_tab_sec">
									<a href="<?php the_permalink()?>">
										<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
										<div class="single_tabimage_video">
											<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
												<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
												echo wp_oembed_get( $url );?>
											</div>
										</div>
										<i class="fa fa-play" aria-hidden="true"></i>
										<?php } ?>
									</a>
                                <div class="heading_2">
                                    <div class="tab_padding">
                                        <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                </div>
                            </div>

                            <div class="single_tab_border"></div>
							
							<?php
								endwhile; endif;
								wp_reset_query();
								?>
								
								

                            
                            </div>                                          
                        </div>
                    </div>
                </div>

                
                










            </div>
        </div>

    </div>
</section>

 <?php get_footer();?>  