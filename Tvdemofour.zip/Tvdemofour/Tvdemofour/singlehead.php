<?php get_header();
global $themesdealer; ?>	
	


<!------------ Top Header Section Start -------------->


<section class="top_header_section">		
<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>		

    
    <div class="row">
        <div class="col-md-10 col-sm-9 col-xs-12">
            <div class="top_hdr_menu">

                <span> <i class="fa fa-calendar-o "> </i> 
					<?php if($themesdealer['content-translatetor'] ==1 ): ?>							
						<?php 
						date_default_timezone_set('Asia/Dhaka');
						echo bangla_date(date('D, d M Y, h:i a'));
						//__________________________________________
						?>
						
						<?php endif; ?>
			   
						<?php if($themesdealer['content-translatetor'] == 2 ): ?>
						<?php
						date_default_timezone_set('Asia/Dhaka');
						$today = date("F j, Y, g:i a"); 
						echo $today;
						?> 
						<?php endif; ?> 
					</span>

                
					<?php
						wp_nav_menu( array('theme_location' => 'top-menu',
					)); ?>
					
					<?php if($themesdealer['language'] == 1 ): ?>
									
					<span2>
						<?php echo do_shortcode('[gtranslate]'); ?> 
					</span2>
					<?php endif; ?>
				<?php if($themesdealer['language'] == 2 ): ?>
					<?php endif; ?>

            </div>
        </div>                   
        <div class="col-md-2 col-sm-3 col-xs-12">
            
            <div class="date_social">
                <ul>
                    <li><a href="<?php echo $themesdealer['social-link']['facebook-url']; ?>" target="_blank" class="hdr_facebook"> <i class="fa fa-facebook"></i></a></li>
                    <li><a href="<?php echo $themesdealer['social-link']['twitter-url']; ?>" target="_blank" class="hdr_twitter"> <i class="fa fa-twitter"></i></a></li>
                    <li><a href="<?php echo $themesdealer['social-link']['instagram-url']; ?>" target="_blank" class="hdr_instagram"> <i class="fa fa-instagram"></i></a></li>
                    <li><a href="<?php echo $themesdealer['social-link']['android-url']; ?>" target="_blank" class="hdr_android"> <i class="fa fa-android"></i></a></li>
                    <li><a href="<?php echo $themesdealer['social-link']['youtube-url']; ?>" target="_blank" class="hdr_youtube"> <i class="fa fa-youtube"></i></a></li>
                </ul>

            </div>

        </div>                  
    </div>

</div>
</section>

<section class="logo_banner_sec">
    <?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>
        <div class="row">
                
            <div class="col-md-4 col-sm-4">
                <div class="hd_logo">
                    <a href="<?php bloginfo('url'); ?>"><img src="<?php echo $themesdealer['logo_upload']['url']?>" alt="Logo" width="100%"></a>
                </div>
            </div>
            <div class="col-md-8 col-sm-8">
                <div class="hd_banner">
                    <a href="<?php echo $themesdealer['bannar-link']['bannar-url']; ?>" target="_blank"><img src="<?php echo $themesdealer['bannar_upload']['url']?>"></a>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="hdr_menu_section" data-spy="affix" data-offset-top="197" role="navigation">
	<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>	
    <div class="row">
        <div class="col-xs-10 col-md-11 col-sm-11">
            <div id="menu-area" class="menu_area">
                <div class="menu_bottom">
                    <nav role="navigation" class="navbar navbar-default mainmenu">
                <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <!-- Collection of nav links and other content for toggling -->
                        <div id="navbarCollapse" class="collapse navbar-collapse">
                            <?php /* Primary navigation */
							wp_nav_menu( array(
						   'theme_location' => 'main-menu',
						   'menu_class'    => 'nav navbar-nav',
						   'fallback_cb' => 'default_main_menu',
						   'walker' => new wp_bootstrap_navwalker())
							  );
							?>
                        </div>
                    </nav>
                                
                </div><!-- /.header_bottom -->

            </div>
        </div>

        

        <div class=" col-xs-2 col-md-1 col-sm-1">
            <div class="search_box">
                <div class="search-icon-holder"> <a href="#" class="search-icon" data-toggle="modal" data-target=".bd-example-modal-lg"><i class="fa fa-search" aria-hidden="true"></i></a>
                    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i class="fa fa-times-circle" aria-hidden="true"></i> </button>
                                </div>
                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="search_box">
                                                     <form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
                                                    <input type="search" name="s" class="form-control input-sm" maxlength="64" placeholder="<?php echo $themesdealer['placeholder']?>"/>
                                                    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-search"></i> </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>



<section class="page_scrool_section">
<?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>
    
    <!------------ website scrool Start -------------->

<div class="row">
<div class="col-md-12 full_scrool">
<div class="col-xs-4 col-md-2 col-sm-3 front_scrool">
	<?php echo $themesdealer['hd_scroll_title'] ?>
</div>
<div class=" col-xs-8 col-md-9 col-sm-7 behind_scrool">
	<?php if($themesdealer['top_scroll_cat'] ==1 ): ?>
				
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php 
	$devs_home = new WP_Query(array(
	'post_type' => 'post',
	'posts_per_page' => $themesdealer['top_how_scroll'],
	));
	while($devs_home->have_posts()) : $devs_home->the_post(); ?>
	<i class="fa fa-circle-o" aria-hidden="true"></i>
	<a href="<?php the_permalink()?>"><?php the_title();?></a>
	<?php endwhile; ?>
	</marquee>
	
	<?php endif; ?>
	<?php if($themesdealer['top_scroll_set'] == 2 ): ?>
	
	
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php
	$cat = $themesdealer['top_scroll_cat'];
	$category_name = get_the_category_by_id($cat);
	$category_name_link = get_category_link($cat);
	$themes_dealer = new WP_Query(array(
		'post_type' => 'post',
		'posts_per_page' => $themesdealer['top_how_scroll'],
		'cat' => $cat,

	));
	while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
	<i class="fa fa-circle-o" aria-hidden="true"></i>
	<a href="<?php the_permalink()?>"><?php the_title();?></a>
	<?php endwhile; ?>
	</marquee>
	
	<?php endif; ?>
	<?php if($themesdealer['top_scroll_set'] == 3 ): ?>
	
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php echo $themesdealer['top_notice_text'] ?>
	</marquee>
	
	<?php endif; ?>
</div>
<div class="col-md-1 col-sm-2 scrool_image">
	<a href="<?php echo $themesdealer['scroolone-link']['scroolone-url']; ?>" target="_blank"><img src="<?php echo $themesdealer['scroolone_upload']['url']?>"></a>
</div>
</div>
</div>

    <!------------ website scrool Close -------------->

    </div>
</section>

<section class="page_scrool_section">
    <?php if($themesdealer['full-body-website'] == 1 ): ?>		
	<div class="container">			
	<?php endif; ?>   
	<?php if($themesdealer['full-body-website'] == 2 ): ?>			
	<div class="container-fluid">					
	<?php endif; ?>
    <!------------ website scrool Start -------------->

<div class="row">
<div class="col-md-12 full_scrool">
<div class="col-xs-4 col-md-2 col-sm-3 front_scrool">
	<?php echo $themesdealer['scroll_title'] ?>
</div>
<div class=" col-xs-8 col-md-9 col-sm-7 behind_scrool">
	<?php if($themesdealer['bottom_scroll_set'] ==1 ): ?>
				
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php 
	$devs_home = new WP_Query(array(
	'post_type' => 'post',
	'posts_per_page' => $themesdealer['how_scroll'],
	));
	while($devs_home->have_posts()) : $devs_home->the_post(); ?>
	<i class="fa fa-circle-o" aria-hidden="true"></i>
	<a href="<?php the_permalink()?>"><?php the_title();?></a>
	<?php endwhile; ?>
	</marquee>
	
	<?php endif; ?>
	<?php if($themesdealer['bottom_scroll_set'] == 2 ): ?>
	
	
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php
		$cat = $themesdealer['scroll_cat'];
		$category_name = get_the_category_by_id($cat);
		$category_name_link = get_category_link($cat);
		$themes_dealer = new WP_Query(array(
			'post_type' => 'post',
			'posts_per_page' => $themesdealer['how_scroll'],
			'cat' => $cat,

		));
	while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
	<i class="fa fa-circle-o" aria-hidden="true"></i>
	<a href="<?php the_permalink()?>"><?php the_title();?></a>
	<?php endwhile; ?>
	</marquee>
	
	<?php endif; ?>
	<?php if($themesdealer['bottom_scroll_set'] == 3 ): ?>
	
	<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
	<?php echo $themesdealer['notice_text'] ?>
	</marquee>
	
	<?php endif; ?>
</div>
<div class="col-md-1 col-sm-2 scrool_image">
	<a href="<?php echo $themesdealer['scrooltwo-link']['scrooltwo-url']; ?>" target="_blank"><img src="<?php echo $themesdealer['scrooltwo_upload']['url']?>"></a>
</div>
</div>
</div>

    <!------------ website scrool Close -------------->

</div>
</section>