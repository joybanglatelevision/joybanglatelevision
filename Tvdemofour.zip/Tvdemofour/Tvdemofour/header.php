<?php global $themesdealer; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://themesdealer.com">
<title><?php wp_title('');  ?></title>  

<link rel="icon" href="<?php echo $themesdealer['favicon']['url']?>" type="image/x-icon" />
<link rel="shortcut icon" href="<?php echo $themesdealer['favicon']['url']?>" type="image/x-icon" />       

<?php
if (is_front_page() && is_home()){ ?>
<meta property="og:title" content="<?php bloginfo('name'); ?>" /> 
<meta property="og:description" content="<?php bloginfo('description'); ?>" />  
<meta property="og:image" content="<?php echo $themesdealer['logo_upload']['url']?>" /> 
<meta property="og:video" content="" /> 
<meta property="og:image:width" content="620" />  
<meta property="og:image:height" content="200" />  
<meta property="og:video:type" content="application/x-shockwave-flash" />
<?php }; if (is_single()){ ?>
<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-thumbnail' ); ?>
<meta property="og:title" content="<?php the_title(); ?>" /> 
<meta property="og:description" content="<?php the_excerpt_rss(); ?>" />  
<meta property="og:image" content="<?php echo $image[0]; ?>" /> 
<meta property="og:video" content="" /> 
<meta property="og:video:width" content="560" />  
<meta property="og:video:height" content="340" />  
<meta property="og:video:type" content="application/x-shockwave-flash" />
<?php };?>

<!-- head section -->
<!-- skin -->
<link rel="stylesheet" href="https://releases.flowplayer.org/7.2.6/skin/skin.css">
<!-- CDNBye hls.js -->
<script src="https://cdn.jsdelivr.net/npm/cdnbye@latest/dist/hls.light.min.js"></script>
<!-- flowplayer -->
<script src="https://releases.flowplayer.org/7.2.6/flowplayer.min.js"></script>

<?php wp_head();?>
<?php include('assets/css/day-css.php'); ?>

</head>
<body>



