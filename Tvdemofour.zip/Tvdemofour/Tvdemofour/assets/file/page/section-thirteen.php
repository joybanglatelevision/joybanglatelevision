<?php global $themesdealer; ?>	
	
	
<section class="video_section_two">
	<div class="row">
		
		<div class="col-md-6 col-sm-6">
			
			<?php
				$cat = $themesdealer['acat-eight'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
			<div class="video_cat_title">
				<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
			</div>

			<div class="row">
			   <div class="col-md-12">
				   <div class="tv_videoslide_padding">
						<div class="tv_videoslide_catagory">
							<div class="videoslide_catagory owl-carousel">
								
								<?php
								$category_name = get_the_category_by_id($cat);
								$how_cat= $themesdealer['ahow_post_eight'];
								$total_how_cat=$how_cat-0;
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $total_how_cat,
									'offset' => 0,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="box_shadow_two">
									<div class="leadnews_image">
										<div class="news_video_sec">
											<a href="<?php the_permalink()?>">
												<?php if(has_post_thumbnail()){ 
													the_post_thumbnail();}
													else{?>
												<div class="news_video">
													<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
														<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
														echo wp_oembed_get( $url );?>
													</div>
												</div>
												<i class="fa fa-play" aria-hidden="true"></i>
												<?php } ?>
											</a>
										</div>
										
										<div class="content_padding">
											<div class="lead_height_1">
												<div class="heading_1">
													<a href="<?php the_permalink()?>"><?php the_title() ?></a>
												 </div>
											 </div>
										 </div>
									</div>
								</div>

								<?php endwhile?>

							</div>
						</div>
									
					</div>
			   </div> 
			</div>
		</div>

		<div class="col-md-6 col-sm-6">
			
			<?php
				$cat = $themesdealer['acat-nine'];
				$category_name = get_the_category_by_id($cat);
				$category_name_link = get_category_link($cat); 
				?>
				
			<div class="video_cat_title">
				<i class="fa fa-video-camera"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
			</div>

			<div class="row">
			   <div class="col-md-12">
				   <div class="tv_videoslide_padding">
						<div class="tv_videoslide_catagory">
							<div class="videoslide_catagory owl-carousel">
								
								<?php
								$category_name = get_the_category_by_id($cat);
								$how_cat= $themesdealer['ahow_post_nine'];
								$total_how_cat=$how_cat-0;
								$themes_dealer = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => $total_how_cat,
									'offset' => 0,
									'cat' => $cat,

								));
								while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
								
								<div class="box_shadow_two">
									<div class="leadnews_image">
										<div class="news_video_sec">
											<a href="<?php the_permalink()?>">
												<?php if(has_post_thumbnail()){ 
													the_post_thumbnail();}
													else{?>
												<div class="news_video">
													<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
														<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
														echo wp_oembed_get( $url );?>
													</div>
												</div>
												<i class="fa fa-play" aria-hidden="true"></i>
												<?php } ?>
											</a>
										</div>
										
										<div class="content_padding">
											<div class="lead_height_1">
												<div class="heading_1">
													<a href="<?php the_permalink()?>"><?php the_title() ?></a>
												 </div>
											 </div>
										 </div>
									</div>
								</div>

								<?php endwhile?>

							</div>
						</div>
									
					</div>
			   </div> 
			</div>
		</div>

	</div>
</section>


<section class="widget_section">
	<?php dynamic_sidebar('widget_area_13')?>
</section>