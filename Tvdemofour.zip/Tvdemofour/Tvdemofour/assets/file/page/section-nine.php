<?php global $themesdealer; ?>




        <div class="news_section_one">
					
					<?php
					$cat = $themesdealer['acat-two'];
					$category_name = get_the_category_by_id($cat);
					$category_name_link = get_category_link($cat); 
					?>
					
                    <div class="cat_title">
                        <i class="fa fa-bars"></i> <a href="<?php echo esc_url($category_name_link);?>"> <?php echo $category_name;?> </a>
                    </div>

                    <div class="row">
                        <div class="col-md-12 col-sm-12">
							<?php
							$cat = $themesdealer['acat-two'];
							$category_name = get_the_category_by_id($cat);
							$category_name_link = get_category_link($cat);
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' =>1,
								'offset' => 0,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
					
                            <div class="exclusive_smlimg_sec">
                                
								<a href="<?php the_permalink()?>">
									<?php if(has_post_thumbnail()){ 
										the_post_thumbnail();}
										else{?>
									<div class="exclusive_smlimg_video">
										<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
											<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
											echo wp_oembed_get( $url );?>
										</div>
									</div>
									<i class="fa fa-play" aria-hidden="true"></i>
									<?php } ?>
								</a>
								
                                <div class="exclusive_padding">
                                    <div class="heading_1">
                                       <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                    </div>
                                    <div class="coltent_dtails">
                                          <?php echo excerpt($themesdealer['aexcerpt-cat_two']); ?><span style="text-align:right"><a href="<?php the_permalink();?>"><?php echo $themesdealer['read-more-archive']?></a></span> 
                                    </div>
                                </div>
                            </div>
							
							<?php endwhile?>
							
                        </div>
                    </div>

                    <div class="row">
                        
                        <?php
							$category_name = get_the_category_by_id($cat);
							$how_cat= $themesdealer['ahow_post_two'];
							$total_how_cat=$how_cat-1;
							$themes_dealer = new WP_Query(array(
								'post_type' => 'post',
								'posts_per_page' => $total_how_cat,
								'offset' => 1,
								'cat' => $cat,

							));
							while ($themes_dealer->have_posts()) : $themes_dealer->the_post(); ?>
							
                        <div class="col-md-4 col-sm-4">
                            <div class="box_shadow">
                                    <div class="leadnews_image exclusive_image">
                                        <div class="news_video_sec">
                                            <a href="<?php the_permalink()?>">
												<?php if(has_post_thumbnail()){ 
													the_post_thumbnail();}
													else{?>
												<div class="news_video">
													<div class="embed-responsive embed-responsive-16by9 embed-responsive-item">
														<?php $url = esc_url( get_post_meta( get_the_ID(), 'video_link', true ) ); 
														echo wp_oembed_get( $url );?>
													</div>
												</div>
												<i class="fa fa-play" aria-hidden="true"></i>
												<?php } ?>
											</a>
                                        </div>
                                        
                                        <div class="content_padding">
                                        <div class="lead_height_1">
                                            <div class="heading_2">
                                                <a href="<?php the_permalink()?>"><?php the_title() ?></a> 
                                             </div>
                                         </div>
                                     </div>
                                    </div>
                                </div>
                        </div>
                        
						<?php endwhile?>
						
                    </div>                   

                    
                </div>


                <section class="widget_section">
					<?php dynamic_sidebar('widget_area_09')?>
				</section>