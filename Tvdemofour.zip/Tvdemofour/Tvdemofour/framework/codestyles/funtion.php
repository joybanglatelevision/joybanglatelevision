		
<?php global $themesdealer; ?>	
			
			
		

		<!----------  Bottom footer Section Start ---------->


        <section class="btm_footer_section">
            <?php if($themesdealer['full-body-website'] == 1 ): ?>		
			<div class="container">			
			<?php endif; ?>   
			<?php if($themesdealer['full-body-website'] == 2 ): ?>			
			<div class="container-fluid">					
			<?php endif; ?>
                
                <div class="row">
                    <div class="col-sm-6 col-md-8">
                        <div class="copy">
                            <?php echo $themesdealer['copyright']?>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="design_developed">
                            <?php funtion(); ?>
                        </div>
                    </div>
                </div>

                <!--------------- go to top start---------------->

                <a href="" class="TopUp"><i class="fa fa-angle-up"></i></a>

                <!--------------- go to top close---------------->

            </div>
        </section>


    <!----------  Bottom footer Section Close ---------->
	