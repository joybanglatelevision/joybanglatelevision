<?php global $themesdealer ?>


<!------------ Top Header Section Start -------------->


<section class="top_header_section">
<?php if($themesdealer['live_tvp'] == 1 ): ?>		
<div class="container">			
<?php endif; ?>   
<?php if($themesdealer['live_tvp'] == 2 ): ?>			
<div class="container-fluid">					
<?php endif; ?>	
    
    <div class="row">
        <div class="col-md-10 col-sm-9 col-xs-12">
            <div class="top_hdr_menu">

                <span> <i class="fa fa-calendar-o "> </i> 
					<?php if($themesdealer['content-translatetor'] ==1 ): ?>							
						<?php 
						date_default_timezone_set('Asia/Dhaka');
						echo bangla_date(date('D, d M Y, h:i a'));
						//__________________________________________
						?>
						
						<?php endif; ?>
			   
						<?php if($themesdealer['content-translatetor'] == 2 ): ?>
						<?php
						date_default_timezone_set('Asia/Dhaka');
						$today = date("F j, Y, g:i a"); 
						echo $today;
						?> 
						<?php endif; ?> 
					</span>

                
					<?php
						wp_nav_menu( array('theme_location' => 'top-menu',
					)); ?>
					
					<?php if($themesdealer['language'] == 1 ): ?>
									
					<span2>
						<?php echo do_shortcode('[gtranslate]'); ?> 
					</span2>
					<?php endif; ?>
				<?php if($themesdealer['language'] == 2 ): ?>
					<?php endif; ?>

            </div>
        </div>                  
        <div class="col-md-2 col-sm-3 col-xs-12">
            
            <div class="date_social">
                <ul>
                    <li><a href="<?php echo $themesdealer['social-link']['facebook-url']; ?>" target="_blank" class="hdr_facebook"> <i class="fa fa-facebook"></i></a></li>
                    <li><a href="<?php echo $themesdealer['social-link']['twitter-url']; ?>" target="_blank" class="hdr_twitter"> <i class="fa fa-twitter"></i></a></li>
                    <li><a href="<?php echo $themesdealer['social-link']['instagram-url']; ?>" target="_blank" class="hdr_instagram"> <i class="fa fa-instagram"></i></a></li>
                    <li><a href="<?php echo $themesdealer['social-link']['android-url']; ?>" target="_blank" class="hdr_android"> <i class="fa fa-android"></i></a></li>
                    <li><a href="<?php echo $themesdealer['social-link']['youtube-url']; ?>" target="_blank" class="hdr_youtube"> <i class="fa fa-youtube"></i></a></li>
                </ul>

            </div>

        </div>                  
    </div>

</div>
</section>


<!------------ Top Header Section Close -------------->


